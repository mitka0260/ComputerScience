// Exercise 1.4.1

public class OutOfBounds
{
    public static void main(String[] args)
    {
        int[] a = new int[1000];
        
        System.out.println(a[1000]);
    }
}