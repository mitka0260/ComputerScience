// Exercise 1.4.2

public class ArrayTest
{
    public static void main(String[] args)
    {
        int N = 1000;
        int[] a = new int[N*N*N*N];
    }
}