// Exercise 1.4.9

public class CompareArrays
{
    public static void main(String[] args)
    {
        int[] a = { 1, 2, 3 };
        int[] b = { 1, 2, 3 };
        
        System.out.println(a == b); // should be false, not the same array
    }
}